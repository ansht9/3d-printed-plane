# Plane

3D printed airplane.

![](https://github.com/phuang1024/plane/blob/master/images/complete.jpg?raw=true)

**Warning: The design is very weak and it requires a relatively high speed to fly. Also, it can't fly.**

* Flying speed: 9m/s
* Weight: about 600g
